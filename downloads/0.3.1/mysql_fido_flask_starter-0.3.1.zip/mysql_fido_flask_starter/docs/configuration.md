# Gateway configuration reference

## Configuration layers

The reusable `Gateway` class takes explicit Python arguments. It does **not** read environment variables or `.env` files. The [reference app.py](../app.py) imports `create_demo_app` from `mysql_fido_gateway.flask_util` in the installed 0.3.1 wheel, which translates environment values into `Gateway` arguments. Its direct entry point and launcher use isolated Python imports to avoid source-checkout shadowing; `python app.py --check-library` reports the selected version and package location without starting the server. `start.sh` adds shell-file loading, local defaults, token generation, and HTTPS proxy management.

The three separate tutorials use backend 5004 for [create user](create-user-tutorial.md), 5002 for [registration](registration-tutorial.md), and 5003 for [login/main](login-main-tutorial.md). Each includes its own HTTPS proxy target. Create-user and registration use `create_action_app` from the shared Flask helper, with distinct cookie names `gateway_create` and `gateway_register`.

The [login/main tutorial](login-main-tutorial.md) uses backend 5003 and cookie `gateway_login_session`. Its packaged Flask helper also reads `SESSION_TTL_SECONDS` (default 300, range 1–3600) for retained authenticated connections; that variable does not configure the reference app or the first starter.

The effective launcher order is:

1. Inherit the shell environment and parse the local/remote launcher argument.
2. Source project `.env`, if present, exporting assignments. Values assigned there can replace inherited values.
3. Locate `.venv/bin/python` and check the installed wheel using isolated imports. A missing/wrong library exits before token generation or proxy changes.
4. Apply defaults for unset/empty values, except where unset and explicitly empty have different meanings below.
5. In default/`--local` mode, force the browser RP/origin to `localhost` / `https://localhost`.
6. Apply database transport defaults and generate/display the effective administrator token when enabled.
7. In local mode, reload/start the Caddy HTTPS proxy.
8. Start Python with the resulting exported environment and isolated imports.

`config.example.env` is a reference file, not an automatically loaded configuration. Direct `python app.py` does not read `.env`. The launcher treats `.env` as executable shell code, so only source a file you control.

## Explicit Python MySQL configuration

All Flask factories accept `db_config=` and `allow_loopback_plaintext=`. Pass the actual target and TLS settings; no shared database username/password belongs in this mapping:

```python
app, auth = create_gateway_app(
    Path(__file__).parent,
    db_config={
        'host': 'db.example.com',
        'port': 3307,
        'ssl_ca': '/path/to/mysql-ca.pem',
        'ssl_verify_cert': True,
        'ssl_verify_identity': True,
    },
)
```

`db.example.com:3307` is an explicit example, not a default. For deliberate local development, pass your loopback host/port and `allow_loopback_plaintext=True`. If `db_config` is omitted, `DB_HOST` and `DB_PORT` are required in the environment; absence stops startup. Username and password are supplied by each user in the login/registration form, or explicitly to `Gateway.connect(username, password, ask)` / `register(...)` in a custom integration.

The `newapp` generator writes its selected host/port directly into `MYSQL_HOST` and `MYSQL_PORT` in the generated `app.py`, and into `.env`. The app visibly passes those settings to `db_config`; deployment environment values can override the code assignments. `runtime.check_library()` and `runtime.run_demo_app()` hold wheel/startup checks so root `app.py` stays minimal.

## Application environment variables

These are all environment variables currently read by the application or launcher as application settings. `BROWSER_ORIGIN`, RP, and database transport settings should be fixed before app construction; restart after changing configuration.

| Variable | Direct `app.py` default | `start.sh` behavior | Meaning |
| --- | --- | --- | --- |
| `BROWSER_ORIGIN` | `https://localhost`; trailing `/` removed | Local mode forces `https://localhost`; remote mode defaults to `https://$RP_ID` | Exact browser origin used for signed data and POST Origin checks |
| `RP_ID` | `localhost` | Defaults to `localhost`; local mode forces it | WebAuthn relying-party domain; must match the MySQL server challenge |
| `REGISTRATION_MODE` | `browser` | Inherited or loaded from `.env` | `browser` for credential-ID enrollment; `shared` requires a discoverable credential and a compatible browser backend. Sets the initial registration-mode selection in the combined demo; other apps keep this configured policy. Applies only to new registrations; see [shared enrollment](user-manual.md#shared-browser-and-native-client-enrollment) |
| `DB_HOST` | Required; no default | Must be configured | Database connection target; remote TLS needs a certificate-matching hostname |
| `DB_PORT` | Required integer, 1–65535; no default | Must be configured | MySQL classic-protocol TCP port |
| `DB_SSL_CA` | Unset | Inherited or loaded from `.env` | CA file for database TLS; a nonempty value enables certificate and hostname verification |
| `ALLOW_LOOPBACK_DB_PLAINTEXT` | Only exact string `1` enables the exception | Inherited or loaded from `.env`; never inferred | Development exception to mandatory database certificate validation for these loopback host strings only; does not disable TLS |
| `DB_ACCOUNT_HOST` | `localhost` | Defaults to `localhost` | Host part used when creating/dropping a demo account; this is not a connection target |
| `FLASK_SECRET_KEY` | Fresh random 32-byte hex secret when absent/empty | No automatic persistence | Signs the demo session cookie; a stable secret preserves cookie validity but cannot restore pending flows or live connections after restart |
| `ADMIN_TOKEN` | Absent/empty disables administrator actions | For local origin, generates a token only when unset; explicitly empty remains disabled. Prints any nonempty effective token | Application authorization gate for server setup and user creation; not a database password |

The local token is temporary when generated by the launcher. Restarting changes it. The demo intentionally displays its configured token on the page and prefills the administrator-token fields; the create-user tutorial also displays its token. Database passwords and the key PIN are not displayed.

There are no supported `DB_USER`, `DB_PASSWORD`, root-password, YubiKey-PIN, Flask-port, or browser-TLS-certificate environment settings in this application. End-user and root passwords are supplied per form action. Backend bind address/port are fixed in the script entry point.

### Local example

Copy the example to `.env` and review it:

```bash
BROWSER_ORIGIN=https://localhost
RP_ID=localhost
DB_HOST=127.0.0.1
DB_PORT=5316
DB_ACCOUNT_HOST=localhost
ALLOW_LOOPBACK_DB_PLAINTEXT=1
# ADMIN_TOKEN=''   # Uncomment to disable setup and provisioning.
```

Use `./start.sh` and open `https://localhost`. Do not commit `.env` or add real secrets to the example file.

### Remote database and browser example

```bash
export RP_ID=fido.example.com
export BROWSER_ORIGIN=https://fido.example.com
export DB_HOST=mysql.example.com
export DB_PORT=3306
export DB_SSL_CA=/secure/mysql-ca.pem
export DB_ACCOUNT_HOST=gateway.internal.example.com
unset ALLOW_LOOPBACK_DB_PLAINTEXT
./start.sh --remote
```

Replace the account host with the source host MySQL actually matches. Configure stable `FLASK_SECRET_KEY` and, if administrator actions are wanted, `ADMIN_TOKEN` through your secret-management process. Configure the browser-facing HTTPS listener separately; `--remote` does not start it.

## Launcher arguments

| Command | Result |
| --- | --- |
| `./start.sh` | Same as `--local`; localhost HTTPS profile and local proxy setup |
| `./start.sh --local` | Forces local RP/origin, but does not force the database host to be local |
| `./start.sh --remote` | Keeps configured RP/origin and skips local proxy setup |
| Other first argument | Prints usage and exits with status 2 |

The launcher uses the repository's `.venv/bin/python`; it does not create the environment or install dependencies. Default local mode requires Caddy on `PATH`, attempts `caddy reload`, then `caddy start` if reload fails. Flask remains a foreground process; stop it with Ctrl+C. Caddy and MySQL have separate lifecycles.

## Retained Flask login configuration

`mysql_fido_gateway.flask_login.create_gateway_app(root, ...)` uses the same RP/origin and database host/TLS variables, with these differences from the three-in-one demo:

| Setting | Retained-login behavior |
| --- | --- |
| `FLASK_SECRET_KEY` | Required; no generated fallback |
| `SESSION_TTL_SECONDS` | Absolute authenticated lifetime, default 300 seconds, integer range 1–3600; factory `session_seconds=` overrides it |
| Cookie | `gateway_login_session`, HttpOnly, Secure, SameSite Strict; owner and CSRF rotate on successful login |
| Database timeouts | Connect/read/write: 10/15/10 seconds |
| SQL wait and serialization | Up to 20 seconds for each queued operation or session-access lock; an active connection context serializes requests using that login |
| Capacity | At most 32 pending/active login entries; each successful login retains one worker and MySQL connection |
| Transaction defaults | Worker starts with autocommit enabled; `getConnection()` disables it for the context, then commits/rolls back, closes cursors, and restores it |
| Login UI assets | Supplied by the wheel at `/_gateway/static/`; application business assets retain their own static endpoint |
| Backend listener | Set by the application; the login sample uses `127.0.0.1:5003` |

`ADMIN_TOKEN` and `DB_ACCOUNT_HOST` do not enable provisioning in the login utility. Provision the account separately; its key can be enrolled through the login page’s registration link. Process restart loses its live connections even with an unchanged signing secret. Direct sample applications read exported environment values; their app factories do not source `.env`. See the [SQL/session API](api-reference.md#flask-login-and-sql-api).

## Origin and hostnames

| Name | Example | Purpose |
| --- | --- | --- |
| Browser URL | `https://fido.example.com/` | Address the user opens |
| Browser origin | `https://fido.example.com` | Scheme, host, and effective port; does not include a path |
| RP ID | `fido.example.com` | Authenticator credential scope; no scheme, port, or path |
| MySQL `authentication_webauthn_rp_id` | `fido.example.com` | Must agree with the RP ID supplied in the MySQL challenge |
| Database host | `mysql.example.com` | Gateway-to-database connection and database TLS hostname |
| Account host | `gateway.internal.example.com` | Source-host portion of the matched MySQL account |

This code's required equality is:

```text
BROWSER_ORIGIN = "https://" + RP_ID
MySQL authentication_webauthn_rp_id = RP_ID
```

No explicit browser port is accepted, including `:443`; use the canonical origin without it. The RP hostname and database hostname can differ. A remote user's `localhost` refers to their own machine. Changing an RP ID can affect existing registrations and every application sharing that server RP namespace.

General browser support for HTTP localhost does not remove this code's HTTPS check. The presentation-only HTTP example is not a supported application configuration. Signed client data is forwarded unchanged; replacing its scheme/host after the key signs would invalidate its meaning. See the [WebAuthn specification](https://www.w3.org/TR/webauthn-3/).

## Python database configuration parameters

`Gateway(db_config, origin, rp_id, ...)` requires an explicit host and port in `db_config`, copies it, and forwards its connection options to Connector/Python on each operation. The following table lists the relevant options used by this project; it is not an exhaustive Connector/Python option list.

| Key | Type | Reference app value | Meaning |
| --- | --- | --- | --- |
| `host` | `str` | From `DB_HOST` | Database target; Required; no default hostname |
| `port` | `int` | From `DB_PORT` | Target port; required by this library; a missing port is rejected |
| `ssl_ca` | `str` | From `DB_SSL_CA`, when nonempty | CA certificate file path |
| `ssl_verify_cert` | `bool` | `True` when a CA is configured | Require database certificate validation |
| `ssl_verify_identity` | `bool` | `True` when a CA is configured | Require database hostname verification |
| `ssl_disabled` | `bool` | Not set by the reference app | Explicitly disable database TLS; only allowed under the loopback exception |
| `connection_timeout` | Seconds | `10` | Connection-establishment timeout |
| `read_timeout` | Seconds | `180` | Connector read timeout |
| `write_timeout` | Seconds | `15` | Connector write timeout |

Without the loopback exception, the Gateway constructor rejects `ssl_disabled` or missing/false CA/certificate/identity verification settings. The exception permits a connection without verified TLS; it does not force plaintext if the connector negotiates TLS.

Keep MySQL TLS enabled for password authentication. The pinned pure-Python
connector does not implement RSA password exchange for `caching_sha2_password`.
With `ssl_disabled=True`, a newly created account can return 1045 before SQL even
with the correct password. An account previously authenticated over TLS can
appear to work because MySQL caches password authentication; that is not a
reliable plaintext configuration. The reference `app.py` leaves TLS enabled.
See the [real-server reproduction](../VALIDATION.md#fresh-account-password-authentication-and-mysql-tls).

Gateway rejects these keys in `db_config`: `user`, `password`, `password1`, `pool_name`, `pool_size`, and `database`. Keep all account credentials out of this dictionary, including alternate credential option names; the rejection list is not a general-purpose configuration sanitizer. Supply credentials to `register()` or `connect()` and select a business database only after authentication. Do not enable shared-account pooling.

For other options, consult the [official Connector/Python connection arguments](https://dev.mysql.com/doc/connector-python/en/connector-python-connectargs.html) and validate them with this pinned adapter.

## Fixed defaults and limits

These settings describe the demo/action transport. Retained-login differences are listed above. These settings are in code; environment variables do not change them.

| Setting | Current value | Defined in |
| --- | --- | --- |
| Flask backend listener | `127.0.0.1:5001`, debug off, threaded | `app.py` entry point |
| Browser HTTPS listener | Port 443 in supplied proxy configurations | `Caddyfile.local`, `Caddyfile.remote` |
| Browser registration/assertion timeout hint | 120,000 ms | `Challenge.options()` |
| Flow lifetime | 150 seconds from creation | `Flow(owner, ttl=150)`; Broker uses the default |
| Frontend operation deadline | 150,000 ms | `static/gateway.js` |
| MySQL server setup timeout | `max(180, existing connect_timeout)` | Setup action |
| Provisioning minimum server timeout | 150 seconds | Create action |
| Default capacity | 32 current/recent flows | `Broker(max_flows=32)` |
| Per-owner concurrency | One unfinished flow | `Broker.create()` |
| Flow queue capacities | 8 events, 1 reply | `Flow` |
| Poll wait | Up to 1 second before a `waiting` event | Poll endpoint |
| Frontend idle delay | 150 ms after a `waiting` event | Browser script |
| Request body limit | 131,072 bytes | Flask configuration |
| Demo username | 1–32 ASCII letters/digits/underscores; `root` rejected; create requires `demo_` prefix | Start endpoint |
| Demo user password | Nonempty string, at most 1,024 characters | Start endpoint |
| Browser byte-string decoder limit | 180,000 encoded characters per value | `unb64u()` |
| Session cookie | HttpOnly, Secure, SameSite Strict | Flask configuration |

The clocks are independent: changing MySQL `connect_timeout` alone does not extend the browser hint, worker flow lifetime, or JavaScript deadline. `Broker(max_flows=...)` and direct `Flow(..., ttl=...)` construction are Python arguments, not runtime environment settings.
